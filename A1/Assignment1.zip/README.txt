Assignment Structure:
A1-|---Q4_image_1.jpg
   |---Q4_iamge_2.jpg
   |---Yunlong.png
   |---Q6.png
   |---code-|---connected_component_labeling.py
            |---edge_detection.py

Command to run code:
1. To run the code in Question 4, please use command:
   python3 edge_detection.py PATH/TO/IMAGE
   If you want to visualize the Gaussian kernel, please use:
   python3 edge_detection.py PATH/TO/IMAGE --visualize_kernel=True

2. To run the code in Question 5 & 6, please use command:
   python3 connected_component_labeling.py